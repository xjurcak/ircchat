%%%-------------------------------------------------------------------
%%% @author xjurcak
%%% @copyright (C) 2014, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 20. Apr 2014 6:52 PM
%%%-------------------------------------------------------------------
-module(accesspointmanager_sup).
-author("xjurcak").

-behaviour(supervisor).

%% API
-export([start/1]).

%% Supervisor callbacks
-export([init/1]).

-define(SERVER, ?MODULE).

%%%===================================================================
%%% API functions
%%%===================================================================

start(Limit) ->
  {ok, Pid} = supervisor:start_link(?MODULE, {Limit}),
  unlink(Pid),
  Pid.

%%%===================================================================
%%% Supervisor callbacks
%%%===================================================================

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Whenever a supervisor is started using supervisor:start_link/[2,3],
%% this function is called by the new process to find out about
%% restart strategy, maximum restart frequency and child
%% specifications.
%%
%% @end
%%--------------------------------------------------------------------
-spec(init({Limit :: integer()}) ->
  {ok, {SupFlags :: {RestartStrategy :: supervisor:strategy(),
    MaxR :: non_neg_integer(), MaxT :: non_neg_integer()},
    [ChildSpec :: supervisor:child_spec()]
  }} |
  ignore |
  {error, Reason :: term()}).
init({Limit}) ->
  MaxRestart = 1,
  MaxTime = 3600,
  {ok, {{one_for_all, MaxRestart, MaxTime},
    [{serv,
      {accesspointmanager_serv, start_link, [Limit, self()]},
      permanent,
      5000, % Shutdown time
      worker,
      [accesspointmanager_serv]}]}}.

%%%===================================================================
%%% Internal functions
%%%===================================================================
